module JekyllImport
  VERSION = "0.14.0".freeze
end
